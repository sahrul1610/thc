
CKEDITOR.plugins.setLang('html5video', 'he', {
    button: 'הוסף וידאו HTML5',
    title: 'וידאו HTML5',
    infoLabel: 'מידע וידאו',
    allowed: 'סוגי קבצים מורשים: MP4, WebM, Ogv',
    urlMissing: 'כתובת הוידאו חסרה',
    videoProperties: 'מאפייני וידאו',
    upload: 'העלה',
    btnUpload: 'שלח לשרת',
    advanced: 'מתקדם',
    autoplay: 'ניגון אוטומטי?',
    allowdownload: 'Allow download?',
    advisorytitle: 'Advisory title',
    yes: 'כן',
    no: 'לא',
    responsive: 'רוחב רספונסיבי'
});
