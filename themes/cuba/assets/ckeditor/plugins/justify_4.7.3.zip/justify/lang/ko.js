/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'ko', {
	block: '양쪽 맞춤',
	center: '가운데 정렬',
	left: '왼쪽 정렬',
	right: '오른쪽 정렬'
} );
