/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'ja', {
	block: '両端揃え',
	center: '中央揃え',
	left: '左揃え',
	right: '右揃え'
} );
